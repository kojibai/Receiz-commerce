# Testing emulator

Import the browser-safe emulator from `@receiz/sdk/testing`:

```ts
const emulator = createReceizEmulator({ seed: "test", startTimeMs: 1_700_000_000_000 });
const owner = emulator.identity.create("owner");
const record = emulator.proof.record({ ownerId: owner.id, payload: { title: "Test" } });
const result = await emulator.proof.seal(record.id);
if (!result.sandboxVerified) throw new Error("sandbox failure");
```

Sandbox identities are namespaced `sandbox.receiz.test` and never impersonate a real Receiz ID. Continuity exists before sandbox sealing. The emulator covers deterministic proof graphs, proof memory, public store, authenticated webhook envelopes, checkout outcomes, clock control, snapshot/restore, and bounded failure injection.

Emulator evidence uses `sandboxVerified`; it never returns a production `verified` verdict. Only canonical Receiz artifact verification can verify a proof object.
