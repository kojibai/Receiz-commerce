# Connect Transfers

```bash
npm install @receiz/sdk
```

```ts
import { createReceizClient } from "@receiz/sdk";

const receiz = createReceizClient({
  accessToken: process.env.RECEIZ_ACCESS_TOKEN,
});

const transfer = await receiz.connect.transfer(
  {
    recipientUserId: "user_123",
    unit: "phi",
    amountPhi: "10",
    note: "Thanks",
  },
  { idempotencyKey: crypto.randomUUID() },
);

console.log(transfer.ledgerEventId, transfer.proofBundle);
```

Connect transfers are delegated settlement actions. The SDK submits the user-approved action with a bearer token and idempotency key. The settlement primitive is the resulting ledger event and proof bundle, not the HTTP call itself.

Production checklist:

1. Use Authorization Code + PKCE to obtain a user-approved access token.
2. Request only the scopes your app needs, such as `receiz:wallet.transfer`.
3. Send a stable idempotency key for retries.
4. Store the returned ledger event and proof bundle as settlement evidence.
5. Refresh ledger reads for verified additions after the transfer completes.
