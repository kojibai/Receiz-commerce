# Public Proof Rendering

```bash
npm install @receiz/sdk
```

```ts
import { createReceizClient } from "@receiz/sdk";

const receiz = createReceizClient();
const proof = await receiz.publicProof.byUrl("https://example.com/work");

if (!proof.record) {
  await receiz.publicProof.observe({
    url: "https://example.com/work",
    title: "Example Work",
  });
}
```

Public proof rendering should display the proof object, provenance, ownership/custody state, verification affordance, and source material. The API response is a public projection over Receiz proof truth. Do not treat it as a mutable content feed that can replace the underlying proof object.

Recommended UI order:

1. Render the known proof object or manifest immediately.
2. Add public proof records after they resolve.
3. Keep source links and verify links visible.
4. Treat missing public proof records as missing projection, not proof invalidation.
