# Identity Login And Recovery

```bash
npm install @receiz/sdk
```

```ts
import {
  buildReceizIdContinueRequest,
  createReceizClient,
  createReceizIdIdentity,
  projectReceizIdentityAccount,
  readReceizIdentityArtifact,
  signReceizIdentityLoginProof,
  verifyReceizIdentityLoginProof,
} from "@receiz/sdk";
```

Receiz ID, Receiz Key, Identity Record, and Identity Seal are identity primitives. They carry proof-bearing account continuity. Your app should verify and project them locally first, then ask Receiz only for verified additions or delegated API access.

Receiz ID is the default login path. It does not replace PBI/passkey, email magic-link recovery, or OIDC/Connect. PBI/passkey can still create or recover a Receiz account, email can still recover the account, Receiz Key / Identity Record / Identity Seal can still restore it locally, and OIDC/Connect still delegates API access after identity proof. These rails bind to the same account; they are not parallel account models.

## Create A Fresh Receiz ID

```ts
const identity = await createReceizIdIdentity({
  username: "builder",
  displayName: "Builder",
  deviceName: "Builder's device",
});

const account = await projectReceizIdentityAccount(identity.keyFile);

if (!account.portableStateVerified) {
  throw new Error("Receiz ID account-state proof failed");
}
```

Persist the returned identity artifact in your app's durable proof memory. It is not a temporary session object.

## Login With A Receiz Key Or Identity Image

```ts
const keyFile = await readReceizIdentityArtifact(fileOrImageBytes);
const account = await projectReceizIdentityAccount(keyFile);

if (!account.portableStateVerified) {
  throw new Error("Receiz identity artifact proof failed");
}

renderSignedInShell({
  userId: account.owner.uid,
  username: account.owner.username,
  displayName: account.owner.displayName,
  domains: account.domains,
});
```

`readReceizIdentityArtifact` accepts Receiz Key JSON, Identity Record image bytes, or Identity Seal image bytes. The projection is local verified truth; do not block first paint on a server rediscovery pass.

## Prove Control To Your App

```ts
const proof = await signReceizIdentityLoginProof({
  keyFile,
  challengeText: "YOUR_APP_LOGIN_V1\nnonce=server-issued-nonce",
});

const ok = await verifyReceizIdentityLoginProof({
  keyFile,
  challengeB64Url: proof.challengeB64Url,
  signatureB64Url: proof.signatureB64Url,
});

if (!ok) throw new Error("Receiz identity signature failed");
```

Use a fresh challenge from your own app server when you need server-side session issuance. The proof verifies ownership of the Receiz identity key; it does not make your app the authority over Receiz truth.

## Publish Continuity To Receiz

```ts
const receiz = createReceizClient({ baseUrl: "https://receiz.com" });

const response = await receiz.identity.continueReceizId(identity, {
  next: "/profile",
});
```

This calls the existing Receiz ID continuation route. It publishes the same signed proof the Receiz app uses for real account creation/recovery. Use it when your app needs Receiz infrastructure to append global continuity or issue a Receiz session.

When a user has already recovered with PBI/passkey or email, use Receiz ID continuation as the bound default for the same account. Do not remove the recovery rail from your app just because the Receiz ID path is default.

For server-side publication, build the request explicitly:

```ts
const body = await buildReceizIdContinueRequest(identity, {
  next: "/profile",
});

await fetch("https://receiz.com/api/auth/receiz-id/continue", {
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify(body),
});
```

## Connect After Proof Login

Use Connect only when your app needs delegated Receiz API access.

```ts
const connectUrl = receiz.identity.authorizeUrl({
  clientId: process.env.RECEIZ_CLIENT_ID!,
  redirectUri: "https://app.example.com/auth/receiz/callback",
  codeChallenge,
  scope: ["openid", "profile", "receiz:wallet.transfer"],
  state,
});
```

Connect tokens authorize API calls beneath the identity primitive. They are permission artifacts, not the proof root.
