# Errors and repair

Every shared SDK error can be projected with `describeReceizError(error)` as `receiz.sdk.error.v1`.

```ts
try {
  await operation();
} catch (error) {
  const descriptor = describeReceizError(error);
  console.error(descriptor.code, descriptor.rail, descriptor.retryable, descriptor.suggestedRepair);
}
```

The descriptor contains a stable code, safe message, affected rail, retryability, optional missing scope, documentation URL, suggested repair, and authority boundary. Tokens, authorization headers, private keys, webhook secrets, identity key material, and recovery material are redacted.

Repair by stable code. Never reconstruct secrets from an error and never treat successful repair as artifact verification.
