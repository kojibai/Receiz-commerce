# Twin And World

The SDK exposes Receiz World and Live Twin without changing the authority model.

Public World reads and public twin conversations are public surfaces. Owner Twin controls are delegated Connect actions and require a registered OIDC client plus the user-granted scopes your app needs.

```txt
Receiz ID / proof objects / Twin mind artifact -> projection now
Connect token -> delegated API permission
server routes -> sync, append, import, export, execute inside mandate
```

The SDK is convenience, not authority. A Connect token authorizes access after identity proof. It does not replace Receiz ID, the Twin mind artifact, market mandates, proof memory, or settlement primitives.

## Public World Profile

```ts
import { createReceizClient } from "@receiz/sdk";

const receiz = createReceizClient();

const profile = await receiz.world.profile("bjklock", {
  visitorKey: "visitor-local-id",
  threadKey: "thread-local-id",
});

if (!profile.ok) throw new Error(profile.error);

renderWorld(profile.world);
```

## Public Twin Conversation

```ts
const reply = await receiz.world.message("bjklock", {
  visitorKey: "visitor-local-id",
  threadKey: "thread-local-id",
  message: "Can you show me the current offer?",
});

renderReply(reply.reply);
renderWorld(reply.world);
```

Streaming uses the same public route and returns parsed server-sent events:

```ts
for await (const event of receiz.world.streamProfile("bjklock", {
  visitorKey: "visitor-local-id",
  threadKey: "thread-local-id",
  message: "Walk me through this site.",
})) {
  if (event.type === "reply_delta") appendText(event.delta ?? "");
  if (event.type === "reply_done") renderWorld(event.world);
}
```

## OIDC Scopes

For owner actions, register an app and request only the scopes your app needs:

```ts
const authorizeUrl = receiz.identity.authorizeUrl({
  clientId: process.env.RECEIZ_CLIENT_ID!,
  redirectUri: "https://app.example.com/auth/receiz/callback",
  codeChallenge,
  scope: [
    "openid",
    "profile",
    "offline_access",
    "receiz:twin.read",
    "receiz:twin.write",
  ],
  state,
});
```

`receiz:twin.read` allows delegated reads such as market mandate, intent list, Twin approval state, and Twin mind export.

`receiz:twin.write` allows delegated mutations such as saving a market mandate, creating or approving market intents, importing Twin mind artifacts, and approving public Twin promotion when the owner has the required automation entitlement.

## Market Twin Mandate

```ts
const receiz = createReceizClient({
  accessToken: process.env.RECEIZ_ACCESS_TOKEN!,
});

const current = await receiz.twin.marketMandate();

await receiz.twin.saveMarketMandate({
  status: "active",
  executionMode: "approve",
  allowedMarketTypes: ["asset"],
  allowedSides: ["buy", "sell"],
  maxOrderUsd: "25.00",
  maxDailyGrossUsd: "100.00",
  maxDailyLossUsd: "0.00",
});
```

This does not bypass the Market Twin mandate. It edits the mandate through the same server primitive Receiz uses.

## Market Twin Intents

```ts
const created = await receiz.twin.createMarketIntent({
  marketItemId: "asset_123",
  marketType: "asset",
  side: "buy",
  amountUsd: "10.00",
  reason: "Owner-approved storefront inventory test.",
});

if (created.intent?.status === "pending") {
  const approved = await receiz.twin.approveMarketIntent(created.intent.id);
  renderTrade(approved.trade);
}
```

Intent execution remains inside the mandate, risk checks, wallet settlement, and market execution primitives. The SDK does not create a second execution engine.

## Twin Mind Export And Import

```ts
const mindImage = await receiz.twin.exportMind();
await saveFile("receiz-twin-mind.png", mindImage);
```

Import verifies the Twin mind artifact before restore:

```ts
const summary = await receiz.twin.importMind(file);
renderImportSummary(summary.summary);
```

This is file-carried Twin memory. Treat the exported image as a proof object transport. Do not flatten it into generic profile metadata.

## Public Twin Promotion

```ts
const approval = await receiz.twin.approval();

await receiz.twin.approvePromotion({
  performance: {
    style: "photoreal",
    score: 98,
    reason: "Owner-approved public Twin promotion.",
  },
  approvalReference: "external-app-review-001",
  evidenceAssets: [{ kind: "image", url: "https://app.example.com/evidence.png" }],
});
```

Promotion approval still requires the owner account to have the required automation entitlement. A token with `receiz:twin.write` authorizes the app to ask; it does not remove account-level law.

## Business / Developer Account Boundary

Public World reads do not require a business/developer account.

Delegated owner actions require an app registration so Receiz can issue OIDC tokens for that app. In practice, a business/developer account is the correct account type for creating and managing OIDC clients, redirect URIs, scopes, token lifecycle, and production app access.

The user still proves identity through Receiz. The app receives delegated access only after the user authorizes it.
