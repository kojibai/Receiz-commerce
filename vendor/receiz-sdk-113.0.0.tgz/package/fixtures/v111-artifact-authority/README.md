# V111 Artifact-Derived Authority Fixtures

These fixtures qualify the current receiver boundary. Engineers may build any application data or custom workflow they choose, but a conforming Receiz receiver recognizes recovery authority only when every authority-bearing value is derived from independently verified artifact truth.

Historical sealed proof objects remain exact-byte verifiable evidence. Historical runtime admissions, histories, capabilities, plans, and MCP confirmations do not cross the v111 current-authority boundary.
