# Capability discovery

`capabilities.describe()` is deterministic, local, and network-free:

```ts
const descriptor = await receiz.capabilities.describe();
```

It returns the supported rails, descriptor version, required scopes, environments, stability, browser/server/compiler/testing compatibility, operations, entry points, and authority boundaries.

The current v112 descriptor advertises maintained developer outcomes only and reports package compatibility as `>=112.0.0 <113.0.0`:

- the identity rail delegates `profile.update`, which submits profile intent for
  the admitted account and returns the same account UID;
- the proof-store rail creates with `assets.createProofObject`, verifies and
  opens with `artifacts.verifyAndOpen`, downloads SDK-issued native artifacts
  with `artifacts.download`, and appends ownership with
  `ownership.claimBearerAsset`;
- ownership accepts the complete sealed artifact. A payload, database row,
  identity-key projection, proof head, or receipt is not a substitute authority.

Obsolete version-specific operation modules are not package capabilities and
cannot redefine the native profile or artifact operations.

`capabilities.probe(options)` inspects configuration-aware readiness. The legacy callable form remains compatible:

```ts
await receiz.capabilities({ tenantHost, scopes });
await receiz.capabilities.probe({ tenantHost, scopes });
```

A description states support. A probe states configured availability. Neither
verifies an artifact; only the artifact verifier admits the enclosing sealed
proof object.

The v112 local authority surface is explicit:

```ts
const registry = loadReceizCurrentRegistry();
const store = createReceizBrowserAdmissionStore({ databaseName, namespace });
const engine = createReceizAdmissionEngine({
  registry,
  store,
  capabilityVerifier,
  consequenceProjector,
});
const signed = await signReceizCapability({ keyFile, passphrase, payload });

const clientStore = client.admission.browserStore({ databaseName, namespace });
const clientEngine = client.admission.createEngine({
  registry,
  store: clientStore,
  capabilityVerifier,
  consequenceProjector,
});
const clientSigned = await client.identity.signCapability({ keyFile, passphrase, payload });
```

The browser store is durable local admission truth, not cache, and never stores proof objects or sealed artifact bytes. It opens lazily beneath known artifact first paint. v112.0 intentionally does not expose `remoteStore` or `reconcileOffline`; remote global admission and offline-to-global reconciliation remain future bounded rails.
