# Receiz SDK v107.0.0 unified operations

`@receiz/sdk@107.0.0` exposes the Receiz.com identity, profile, media, portable-continuity, generic bearer-ownership, proof-head, receipt, and offline-command primitives through one typed operation language. The SDK projects Receiz proof objects; it does not replace sealed artifact truth or make a local plan, emulator result, or queued command authoritative.

## Client

```ts
import { createReceizClient } from "@receiz/sdk";

const receiz = createReceizClient({
  endpoint: "https://receiz.com",
  accessToken,
});
```

The v107 client exposes:

- `identity.getProfile()`
- `identity.checkUsername()`
- `identity.updateProfile()`
- `identity.publishMedia()`
- `identity.restoreAccount()`
- `identity.appendAccountState()`
- `ownership.claimBearerAsset()`
- `continuity.reconcile()`
- `proof.getHead()`
- `receipts.verify()`
- `offline.executeOrQueue()`
- `offline.resume()`

## Atomic profile append

```ts
const result = await receiz.identity.updateProfile({
  identity,
  expectedHead,
  idempotencyKey,
  profile: {
    username: "new_name",
    displayName: "New Name",
    avatar: rawFile,
  },
});
```

`avatar` accepts either a raw `File`/`Blob` or a previously published `ReceizMediaProofReference`. Username, display name, media proof, and proof head commit together. A username rename remains an append to the original identity. The prior username becomes globally available only after the new claim commits. Verify the returned canonical receipt before updating a public projection.

## Portable identity state

`identity.restoreAccount(bytes, { artifactKind })` accepts `receiz-key`, `identity-record`, `identity-seal`, and `vault` artifacts. It verifies the carried artifact before projecting the same identity and app-scoped state locally. `identity.appendAccountState()` appends only within the caller namespace and rejects cross-namespace writes.

## Generic bearer ownership

```ts
const claim = await receiz.ownership.claimBearerAsset({
  artifactBytes,
  claimantKeyId,
  expectedOwnershipHead,
  idempotencyKey,
});
```

The enclosing Receiz artifact verifies before embedded bearer data is interpreted. The operation covers every qualifying artifact type, including documents, market certificates, profile originals, signal cards, sports cards, and wallet notes. One ownership append commits; the previous owner projection becomes inactive only after that commitment.

## Offline commands

`offline.executeOrQueue()` signs the command envelope with the carried identity. A queued result always has `globallyCommitted: false`. `offline.resume()` preserves per-proof-object FIFO order, verifies canonical receipts for committed commands, and stops a causal lane at its first conflict.

## Stable errors

All v107 errors use `ReceizV107ErrorShape` with a stable `code`, `rail`, `retryable`, and HTTP `status`. Conflict codes include `username_taken`, `stale_proof_head`, `idempotency_conflict`, `ownership_head_stale`, and `continuity_conflict`. A conflict performs no partial write; read the canonical head, review verified additions, create a new intent and idempotency key, then verify the returned receipt.

## Emulator and generator

`createReceizV107Emulator({ seed })` provides eleven deterministic scenarios. Every result is explicitly `emulator_simulation` with `productionVerified: false`. `generateReceizV107Integration()` emits a complete Next.js integration through digest-bound preview/apply and preserves developer-owned extensions.

Receiz proof memory remains first admission only, then append forever.
