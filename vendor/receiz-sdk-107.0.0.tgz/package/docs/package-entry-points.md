# Package entry points

Receiz v107 separates runtime, UI, compiler, and testing code without changing proof authority.

```ts
import { createReceizClient } from "@receiz/sdk";
import { ReceizProvider, useReceiz } from "@receiz/sdk/react";
import { defineReceizApp, inspectReceizProject } from "@receiz/sdk/compiler";
import { createReceizEmulator, runReceizConformance } from "@receiz/sdk/testing";
```

`@receiz/sdk` and `@receiz/sdk/react` contain no transitive `node:*` import. `@receiz/sdk/compiler` is Node-only. `@receiz/sdk/testing` is browser-safe, in-memory, and sandbox-only.

Move legacy compiler imports from the root to `@receiz/sdk/compiler`. Runtime imports remain at the root. Mixed imports must be split. `receiz app upgrade` and `receiz_app_upgrade` report exact safe migrations; ambiguous namespace, default, and dynamic imports require review.

No entry point, compiler result, or testing result outranks a sealed Receiz proof object.
