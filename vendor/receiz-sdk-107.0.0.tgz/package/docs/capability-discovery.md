# Capability discovery

`capabilities.describe()` is deterministic, local, and network-free:

```ts
const descriptor = await receiz.capabilities.describe();
```

It returns the supported rails, descriptor version, required scopes, environments, stability, browser/server/compiler/testing compatibility, operations, entry points, and authority boundaries.

`capabilities.probe(options)` inspects configuration-aware readiness. The legacy callable form remains compatible:

```ts
await receiz.capabilities({ tenantHost, scopes });
await receiz.capabilities.probe({ tenantHost, scopes });
```

A description states support. A probe states configured availability. Neither verifies an artifact.
