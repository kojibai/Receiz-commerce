# CLI And Local Conformance

The Receiz SDK ships an executable `receiz` command for local proof inspection, fixture conformance, and starter generation.

The CLI is convenience, not authority. It uses the same SDK validators, projections, and durable proof memory APIs that developer apps import from `@receiz/sdk`. It does not create a new conformance system, issuer, verifier, server confirmation, database confirmation, or truth layer.

## Application Contract Commands

The v109 application compiler is available through `receiz app`:

```bash
receiz app init --name "My Receiz App" --framework nextjs-app-router --json
receiz app inspect --root . --json
receiz app plan --root . --json
receiz app apply --root . --json
receiz app apply --root . --confirm <preview-digest> --json
receiz app check --root . --json
receiz app upgrade --root . --target 109.0.0 --json
receiz app explain --root . --code <finding-code> --json
```

`inspect`, `plan`, `check`, `upgrade`, and `explain` are read-only. The first
`apply` call returns every proposed file change and a deterministic confirmation
digest without writing. A second call carrying that exact digest may update only
Receiz-generated files and approved `package.json` fields. Repeating the same
operation produces no changes.

Repository inspection does not verify a proof object. Byte-bearing artifacts
must pass SDK `verification.verifyArtifact`; authenticated native Record before
Seal remains the only proof-object creation sequence. CLI output never makes
repository, database, cache, server, or UI state proof authority.

## Install

```bash
npm install @receiz/sdk
```

Run without a local install:

```bash
npx @receiz/sdk conformance
```

## Run Local Fixture Conformance

```bash
npx @receiz/sdk conformance
```

This validates the packaged fixtures:

- `receiz.asset_manifest.v1`
- `receiz.sports_arena.card_manifest.v1`
- `receiz.webhook_event.v1`

Each fixture is inspected or validated. Asset and Sports manifests remain inspection-only; the webhook fixture is validated without being confused with sealed asset truth. No fixture is silently promoted into verified proof memory.

Expected shape:

```json
{
  "ok": true,
  "schema": "receiz.sdk.cli.conformance.v1",
  "summary": {
    "fixtures": 3,
    "proofMemoryEntries": 0,
    "networkCalls": 0,
    "dbCalls": 0
  }
}
```

`networkCalls` and `dbCalls` are zero by design. Local conformance proves deterministic inspection. It does not claim a shape-valid manifest is a verified complete proof object.

## Inspect A Proof Payload

```bash
npx @receiz/sdk inspect ./receiz-asset-manifest.json
```

The command validates one JSON payload and projects display-ready rows. Historical manifests are reported as inspection-only:

```json
{
  "ok": true,
  "schema": "receiz.sdk.cli.inspect.v1",
  "kind": "asset_manifest",
  "admitted": false,
  "knownHead": null
}
```

Only an independently verified register entry has a known head and append-sync boundary.

## Generate A Starter

```bash
npx @receiz/sdk init ./receiz-integration
```

This writes:

```txt
receiz-proof-memory.ts
```

The starter:

- opens durable proof memory through `createReceizProofMemory`
- persists through `createReceizLocalStorageProofMemoryStorage`
- projects asset and Sports manifests for inspection without admission
- admits only independently verified webhook/register entries
- exposes `knownHead()` for append-only sync

It does not include Supabase, service-role keys, or a parallel source of truth.

## Diagnose App Runtime Wiring

```bash
npx @receiz/sdk doctor \
  --tenant-host bjklock.receiz.app \
  --access-token "$RECEIZ_ACCESS_TOKEN" \
  --callback-url https://bjklock.receiz.app/api/auth/receiz/callback \
  --scopes openid,profile,receiz:record,receiz:wallet.read
```

The doctor command prints missing token, tenant host, callback URL, and scope evidence without making network or database calls.

```bash
npx @receiz/sdk deploy-check --tenant-host bjklock.receiz.app
npx @receiz/sdk dev
```

Use these commands before deploy to check that the app is passing the tenant coordinate and that the SDK version is pinned.

## Deterministic Sandbox Commands

```bash
npx @receiz/sdk seed-store --tenant-host demo.receiz.app --products 3
npx @receiz/sdk simulate-checkout --amount-usd 19.95
```

These commands emit deterministic sandbox app-state and checkout payloads for tests, demos, and AI-generated app scaffolds. They do not settle payments or create proof authority.

## Production Rule

Use the CLI to prove your local integration shape, then use the typed SDK APIs in your app:

1. Verify stronger proof truth when bytes come from an untrusted transport.
2. Validate the manifest or event shape.
3. Project display-ready rows from the verified object.
4. Admit the proof object into durable proof memory.
5. Persist the proof memory snapshot.
6. Resume from the known verified proof-memory head and its Kai coordinate.
7. Append later verified additions without rediscovering known truth.

That is the same law Receiz uses internally: first admission only, then append forever.
