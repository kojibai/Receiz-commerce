# Capability discovery

`capabilities.describe()` is deterministic, local, and network-free:

```ts
const descriptor = await receiz.capabilities.describe();
```

It returns the supported rails, descriptor version, required scopes, environments, stability, browser/server/compiler/testing compatibility, operations, entry points, and authority boundaries.

The current v109 descriptor advertises maintained developer outcomes only:

- the identity rail delegates `profile.update`, which submits profile intent for
  the admitted account and returns the same account UID;
- the proof-store rail creates with `assets.createProofObject`, verifies and
  opens with `artifacts.verifyAndOpen`, downloads SDK-issued native artifacts
  with `artifacts.download`, and appends ownership with
  `ownership.claimBearerAsset`;
- ownership accepts the complete sealed artifact. A payload, database row,
  identity-key projection, proof head, or receipt is not a substitute authority.

Obsolete version-specific operation modules are not package capabilities and
cannot redefine the native profile or artifact operations.

`capabilities.probe(options)` inspects configuration-aware readiness. The legacy callable form remains compatible:

```ts
await receiz.capabilities({ tenantHost, scopes });
await receiz.capabilities.probe({ tenantHost, scopes });
```

A description states support. A probe states configured availability. Neither
verifies an artifact; only the artifact verifier admits the enclosing sealed
proof object.
